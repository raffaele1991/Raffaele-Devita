# Bug Bounty Vulnerability Scanner Agent v2.0

## Requisiti
- Python 3.8 o superiore
- pip install requests beautifulsoup4 dnspython Jinja2 urllib3

## Installazione

### 1. Estrai i file
Estrai questo archivio in una cartella a tua scelta.

### 2. Installa le dipendenze Python
```bash
pip install requests beautifulsoup4 dnspython Jinja2 urllib3
```

### 3. Attiva la licenza
```bash
python3 bbscanner_activate BBSC-LA-TUA-CHIAVE
```

### 4. Usa lo scanner
```bash
# Modalita LITE
python3 bbscanner -t example.com

# Modalita PRO
python3 bbscanner_pro -t example.com
```

### 5. Verifica stato licenza
```bash
python3 bbscanner_activate
```

## Comandi utili

```bash
# Scansione completa PRO
python3 bbscanner_pro -t example.com

# Con scope automatico da HackerOne
python3 bbscanner_pro -t example.com --program "https://hackerone.com/example"

# Con notifiche Telegram
python3 bbscanner_pro -t example.com --telegram-token "TOKEN" --telegram-chat "CHAT_ID"

# Solo Nuclei e Nmap
python3 bbscanner_pro -t example.com --pipeline nuclei nmap
```

## Supporto
Per problemi, rinnovi o upgrade: devita.raffaele@gmail.com

## Licenza
Software protetto da licenza commerciale. Chiave personale e non trasferibile.
